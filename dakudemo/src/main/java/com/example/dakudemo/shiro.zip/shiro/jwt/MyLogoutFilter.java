package com.example.dakudemo.shiro.jwt;

import org.apache.shiro.web.filter.authc.LogoutFilter;

public class MyLogoutFilter extends LogoutFilter {

}
